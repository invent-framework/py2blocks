Blockly.Theme.defineTheme("py2blocks", {
	name: "py2blocks",
	base: Blockly.Themes.Classic,
	fontStyle: {
		family: "monospace"
	},
});