"""
Test suite for py2blocks.
"""

import py2blocks


async def test_check():
    assert True
